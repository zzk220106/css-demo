#!/bin/sh
open -n /Applications/Google\ Chrome.app --args --disable-web-security --user-data-dir=/Users/zhaozk/Documents/ChromeData